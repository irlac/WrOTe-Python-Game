#ingame wallets
playerQuartz = 250